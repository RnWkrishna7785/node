const express = require('express');
const app = express();


app.set("view engine","ejs")
app.use(express.urlencoded())

let student = [
    {
        id: 1,
        name: "krishna"
    },

        {
        id: 2,
        name: "gopal"
    },
]

app.get("/",(req,res) => {
    res.render("form",{student})
})

app.post("/insertdata", (req, res) => {
    const { id, name } = req.body;
    let obj ={
        id, name
    }

    student.push(obj)
    res.redirect("/")
})

app.get("/delete",(req,res) => {
    const id = req.query.id;
    let ans = student.filter((el,i) => {
        return el.id!==id
    })
    student = ans;
    res.redirect("/");
})




app.get("/edit",(req,res) => {
    const id = req.query.id;
    let ans = student.filter((el,i) => {
        return el.id==id
    })
    res.render("edit",{editvalue:ans[0]})
})

app.post("/editdata",(req,res) => {
    const { id, name } = req.body;
    
        let obj = {
            id, name
        }
student.push(obj)
    res.redirect("/")
})

app.listen(5678,() => {
    console.log('Server is running on port 5678');
})