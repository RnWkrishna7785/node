const express = require('express');
const app = express();

app.set("view engine", "ejs");
app.use("/" ,express.static("public"));

const Middlware = (req, res, next) => {
  if (req.query.age >= 18) {
    next();
  }
  else {
    res.send("You cannot access this page");
  }
}

app.get("/", (req, res) => {
  res.render("index");
});

app.get("/contact", Middlware, (req, res) => {
  res.render("contact");
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});