const userModel = require("../userModels/usermodel");

const add = async (req, res) => {
    const data = await userModel.create(req.body);
    return res.send(data);
}

const getAlluser = async (req, res) => {
    const data = await userModel.find();
    return res.send(data);
}

// const deleteUser = async (req, res) => {
//     const id = req.params.id;
//     await userModel.findByIdAndDelete(id);
//     return res.send("success");
// }   

// const updateUser = async (req, res) => {
//     const id = req.params.id;
//     await userModel.findByIdAndUpdate(id, req.body);
//     return res.send("updated");
// }   
module.exports = { add, getAlluser };