const express = require('express');
const db = require("./config/db");
const U_router = require("./router/userRouter");


const app = express();
app.use(express.json());


app.use("/user", U_router);
app.listen(5656, () => {
    console.log("server started at port 5656");
})
