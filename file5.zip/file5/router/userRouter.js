const express = require('express');
const { add, getAlluser } = require('../controller/userContrller');


const U_router = express.Router();
U_router.post('/add', add);
U_router.get('/get', getAlluser);

module.exports = U_router;